import React, { useState, Fragment, useEffect } from "react";
import UserTable from "./tables/UserTable";
import AddUserForm from "./forms/AddUserForm";
import EditUserForm from "./forms/EditUsersForm";

const App = () => {
  const usersData = [
    { id: 1, name: "OM", dep: "back-end", sal: "10000" },
    { id: 2, name: "Shubham.", dep: "front-end", sal: "999" },
  ];

  // sets initial form state - "blank slate"
  const initialFormState = { id: null, name: "", dep: "", sal: "" };

  const [employee, setEmployee] = useState(usersData);
  const [oldUsersData, setOldUsersData] = useState([]);
  const [editing, setEditing] = useState(false);
  const [currentUser, setCurrentUser] = useState(initialFormState);

  useEffect(() => {
    setOldUsersData(employee);
  }, [""]);

  // increment the ID of the new employee
  const addUser = (user) => {
    user.id = Number(employee.length + 1);
    setEmployee([...employee, user]);
    setOldUsersData([...employee, user]);
  };

  // pass deleteUser through props to UserTable
  const deleteUser = (id) => {
    setEditing(false);
    setEmployee(employee.filter((user) => user.id !== id));
  };

  const editRow = (user) => {
    setEditing(true);
    setCurrentUser({
      id: user.id,
      name: user.name,
      dep: user.dep,
      sal: user.sal
    });
  };

  const updateUser = (id, updatedUser) => {
    setEditing(false);
    setEmployee(employee.map((user) => (user.id === id ? updatedUser : user)));
  };

  const filterEmp = (val, u) => {
    if (val !== "") {
      const newFilterData = oldUsersData.filter((item) => {
        return item.dep.toLocaleLowerCase().includes(val.toLocaleLowerCase());
      });
      setEmployee(newFilterData);
    } else {
      setEmployee(oldUsersData);
    }
  };

  const filterSal = (val) => {
    if (val !== '') {
      if (val == 'low') {
        setEmployee([...employee?.sort((a, b) => (a.sal - b.sal))]);
      }
      if (val == 'high') {
        setEmployee([...employee?.sort((a, b) => (b.sal - a.sal))]);
      }
    } else {
      setEmployee([...employee?.sort((a, b) => (a.id - b.id))]);
    }
  }


  return (
    <div className="container">
      <h1>Employee Table</h1>
      <div className="flex-row">
        <div className="flex-large">
          {editing ? (
            <Fragment>
              <h2>Edit User</h2>
              <EditUserForm
                editing={editing}
                setEditing={setEditing}
                currentUser={currentUser}
                updateUser={updateUser}
                deleteUser={deleteUser}
              />
            </Fragment>
          ) : (
            <Fragment>
              <h2>Add Employee</h2>
              <AddUserForm addUser={addUser} />
            </Fragment>
          )}
        </div>
        <div className="flex-large">
          <h2>View Employee</h2>
          <UserTable
            filterEmp={(val, u) => filterEmp(val, u)}
            filterSal={(value) => filterSal(value)}
            employee={employee}
            editRow={editRow}
            deleteUser={deleteUser}
          />
        </div>
      </div>
    </div>
  );
};

export default App;
