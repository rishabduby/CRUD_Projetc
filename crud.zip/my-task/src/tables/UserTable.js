import React from "react";

const UserTable = (props) => (

    <table>
        <thead>
            <tr>
                <th>Employee Name</th>
                <th>
                    Department
                    <select
                        onChange={(e) => props.filterEmp(e.target.value, props.employee)}
                    >

                        <option value="">All data</option>
                        <option value="back-end">back-end</option>
                        <option value="front-end">front-end</option>
                    </select>
                </th>

                <th>
                    Salary
                    <select
                        onChange={(e) => props.filterSal(e.target.value)}
                    >
                        <option value="">All</option>
                        <option value="high">High</option>
                        <option value="low">low</option>
                    </select>
                </th>
                <th>action</th>
            </tr>
        </thead>
        <tbody>
            {props.employee.length > 0 ? (
                props.employee.map((user) => (
                    <tr key={user.id}>
                        <td>{user.name}</td>
                        <td>{user.dep}</td>
                        <td>{user.sal}</td>
                        <td>
                            <button
                                onClick={() => {
                                    props.editRow(user);
                                }}
                                className="btn btn-warning"
                            >
                                Edit
                            </button>
                            <button
                                onClick={() => props.deleteUser(user.id)}
                                className="btn btn-danger"
                            >
                                Delete
                            </button>
                        </td>
                    </tr>
                ))
            ) : (
                <tr>
                    <td colSpan={3}>No Users....</td>
                </tr>
            )}
        </tbody>
    </table>
);

export default UserTable;
