import React, { useState } from "react";

const AddUserForm = (props) => {
    const initialFormState = { id: null, name: "", dep: "", sal: "" };
    const [employee, setEmployee] = useState(initialFormState);


    // update state based on event in input
    const inputHandler = (event) => {
        const { name, value } = event.target;
        setEmployee({ ...employee, [name]: value });
    };

    return (
        <form
            onSubmit={(event) => {
                event.preventDefault();
                if (!employee.name || !employee.dep || !employee.sal) {
                    alert("All fields all required");
                    return;
                } else {
                    props.addUser(employee);
                    setEmployee(initialFormState);
                }
            }}
        >
            <label>Employee Name</label>
            <input
                type="text"
                name="name"
                placeholder="Enter a name..."
                value={employee.name}
                onChange={inputHandler}
            />
            <label>Department</label>
            <input
                type="text"
                name="dep"
                placeholder="Enter a dep..."
                value={employee.dep}
                onChange={inputHandler}
            />
            <label>Salary</label>
            <input
                type="text"
                name="sal"
                placeholder="Enter a salary..."
                value={employee.sal}
                onChange={inputHandler}
            />
            <button className="btn btn-success">Add New Employee</button>
        </form>
    );
};

export default AddUserForm;
