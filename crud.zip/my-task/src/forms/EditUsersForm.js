import React, { useState, useEffect } from "react";

const EditUserForm = (props) => {
    const [employee, setEmployee] = useState(props.currentUser);

    const handleInputChange = (event) => {
        const { name, value } = event.target;

        setEmployee({ ...employee, [name]: value });
    };

    useEffect(() => {
        setEmployee(props.currentUser);
        console.log({ props })
    }, [props]);

    return (
        <form
            onSubmit={(event) => {
                event.preventDefault();

                props.updateUser(employee.id, employee);
            }}
        >
            <label>Name</label>
            <input
                type="text"
                name="name"
                value={employee.name}
                onChange={handleInputChange}
            />
            <label>Department</label>
            <input
                type="text"
                name="dep"
                value={employee.dep}
                onChange={handleInputChange}
            />
            <label>Salary</label>
            <input
                type="text"
                name="sal"
                value={employee.sal}
                onChange={handleInputChange}
            />
            <button className="btn btn-success">Update Employee</button>
            <button
                onClick={() => props.setEditing(false)}
                className="btn btn-warning"
            >
                Cancel
            </button>
        </form>
    );
};

export default EditUserForm;
